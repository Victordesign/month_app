import challenges
from django import http
from django.shortcuts import render
from django.http import Http404,HttpResponse, HttpResponseNotFound,HttpResponseRedirect, response
from django.urls import reverse
from django.template.loader import render_to_string
# Create your views here.

# key pair value
month_dic = {
  "january":"eat more",
  "febuary":"sleep more",
  "march":"play more",
  "april":"learn more",
  "may":"eat more",
  "june":None
}

# main home url
def index(request):
  months = list(month_dic.keys())
  return render(request,"challenges/index.html",{
    "list_month":months
  })

# input number in the parameter
def month_number(request,month):
  months = list(month_dic.keys())
  if month > len(months):
    return HttpResponseNotFound("this month is not found")

  redirect_month = months[month -1]
  redirect_path = reverse("month-challenges",args=[redirect_month])
  return HttpResponseRedirect(redirect_path)


# parameter by month name
def month_challenges(request,month):
  try:
    challenges_text = month_dic[month]
    return render(request,"challenges/challenges.html",{
      "text":challenges_text,
      "month_name":month
    })
  except:
     response_data = render_to_string("404.html")
     return HttpResponseNotFound("this month is not found!")

  